// api.js
// --------
// This file exports functions that wrap Chakram HTTP calls.
// In your test files, you can import these functions and assert on their responses.
//
// Usage in a test file (example):
//   const { getUser, createUser } = require('./api');
//   describe('User endpoints', () => {
//     it('should fetch a user by ID', () => {
//       return getUser(123).then(response => {
//         expect(response).to.have.status(200);
//         expect(response.body).to.have.property('id', 123);
//       });
//     });
//   });

const chakram = require('chakram');
const expect = chakram.expect;

// Base URL for all API requests � change to your server�s address
const BASE_URL = 'https://api.example.com/v1';

// Generic GET request
function apiGet(path, queryParams = {}) {
    const url = `${BASE_URL}${path}`;
    return chakram.get(url, { qs: queryParams });
}

// Generic POST request
function apiPost(path, body = {}, headers = {}) {
    const url = `${BASE_URL}${path}`;
    return chakram.post(url, body, { headers });
}

// Generic PUT request
function apiPut(path, body = {}, headers = {}) {
    const url = `${BASE_URL}${path}`;
    return chakram.put(url, body, { headers });
}

// Generic DELETE request
function apiDelete(path, headers = {}) {
    const url = `${BASE_URL}${path}`;
    return chakram.delete(url, null, { headers });
}

// -----------------------------------------------------
// Example endpoint-specific functions
// -----------------------------------------------------

/**
 * Fetch user details by user ID.
 * @param {number|string} userId
 * @returns {Promise<ChakramResponse>}
 */
function getUser(userId) {
    // GET /users/:id
    return apiGet(`/users/${userId}`);
}

/**
 * Create a new user.
 * @param {Object} userData  e.g. { name: 'Alice', email: 'alice@example.com' }
 * @returns {Promise<ChakramResponse>}
 */
function createUser(userData) {
    // POST /users
    return apiPost('/users', userData, {
        'Content-Type': 'application/json'
    });
}

/**
 * Update an existing user by ID.
 * @param {number|string} userId
 * @param {Object} updates   e.g. { email: 'new@example.com' }
 * @returns {Promise<ChakramResponse>}
 */
function updateUser(userId, updates) {
    // PUT /users/:id
    return apiPut(`/users/${userId}`, updates, {
        'Content-Type': 'application/json'
    });
}

/**
 * Delete a user by ID.
 * @param {number|string} userId
 * @returns {Promise<ChakramResponse>}
 */
function deleteUser(userId) {
    // DELETE /users/:id
    return apiDelete(`/users/${userId}`);
}

// -----------------------------------------------------
// Export all functions so tests can import them.
// -----------------------------------------------------
module.exports = {
    // Generic methods (optional to export)
    apiGet,
    apiPost,
    apiPut,
    apiDelete,

    // Endpoint-specific
    getUser,
    createUser,
    updateUser,
    deleteUser
};
