// test/postEndpoint.test.js
// -------------------------
// Template for testing a POST endpoint using Mocha, Chakram, and Chai.
// Adjust BASE_URL, endpoint path, payload schema, and assertions as needed.

const chakram = require('chakram');
const expect = chakram.expect;

// Base URL for the API under test
const BASE_URL = 'https://api.example.com/v1';

describe('POST /resources', () => {
    /**
     * Test case: Successfully create a new resource when providing valid data.
     */
    it('should create a new resource with valid data and return 201', () => {
        // Example payload�adapt fields to match your API�s schema
        const validPayload = {
            name: 'Sample Resource',
            description: 'This is a test resource.',
            isActive: true
        };

        return chakram
            .post(`${BASE_URL}/resources`, validPayload, {
                headers: { 'Content-Type': 'application/json' }
            })
            .then((response) => {
                // 1. Status code
                expect(response).to.have.status(201);

                // 2. Content-Type header (should be JSON)
                expect(response).to.have.header('content-type', /application\/json/);

                // 3. Response body should include an �id� and echo back at least the �name� field
                expect(response.body).to.have.property('id');
                expect(response.body).to.have.property('name', validPayload.name);

                // 4. Optionally, verify any default or server-generated fields
                expect(response.body).to.have.property('createdAt');
                expect(new Date(response.body.createdAt)).to.be.a('date');
            });
    });

    /**
     * Test case: Attempt to create a resource with missing required fields.
     * Expect a 400 (Bad Request) or whatever your API returns on validation failure.
     */
    it('should return 400 Bad Request when required fields are missing', () => {
        // Omit �name� (assuming it�s required)
        const invalidPayload = {
            description: 'Missing �name� field',
            isActive: false
        };

        return chakram
            .post(`${BASE_URL}/resources`, invalidPayload, {
                headers: { 'Content-Type': 'application/json' }
            })
            .then((response) => {
                expect(response).to.have.status(400);

                // The body should contain an error message or details about why validation failed
                expect(response.body).to.have.property('error');
                // For example, if your API returns a �details� array:
                // expect(response.body).to.have.property('details').that.is.an('array');
            });
    });

    /**
     * Test case: Attempt to create a resource with invalid field types.
     * E.g., sending a string where a boolean is expected.
     */
    it('should return 422 Unprocessable Entity for invalid field types', () => {
        // �isActive� should be a boolean, not a string
        const badTypePayload = {
            name: 'Bad Type Test',
            description: 'isActive is a string here',
            isActive: 'notABoolean'
        };

        return chakram
            .post(`${BASE_URL}/resources`, badTypePayload, {
                headers: { 'Content-Type': 'application/json' }
            })
            .then((response) => {
                expect(response).to.have.status(422);

                // Verify error structure�adjust keys according to your API spec
                expect(response.body).to.have.property('error');
                // Optionally check for a message about �isActive� needing to be boolean
            });
    });

    /**
     * After all tests complete, wait for any pending Chakram assertions.
     */
    after(() => chakram.wait());
});
