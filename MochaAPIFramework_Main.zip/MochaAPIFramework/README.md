# Overview

This framework uses the following: 

- [Mocha](https://mochajs.org/): This is a flexible JavaScript test framework that provides a structured way to organize and run your tests. It handles the asynchronous nature of JavaScript testing and offers features like hooks (before, after, etc.) to set up and tear down test environments.
- [Chai](https://www.chaijs.com/): Chai is an assertion library that makes it easy to write readable tests. It provides a variety of assertion styles (such as "should", "expect", and "assert") that allow you to express the expected outcomes of your tests in a clear and natural language.
- [Chakram](https://dareid.github.io/chakram/): Chakram is specifically designed for testing REST APIs. It builds on top of Mocha and Chai, offering additional methods tailored for sending HTTP requests and verifying responses. This means you can leverage Mocha�s test structure and Chai�s expressive assertions while benefiting from Chakram�s dedicated API testing features.
- [dotenv](https://www.npmjs.com/package/dotenv): Dotenv is a zero-dependency module that loads environment variables from a .env file into process.env. Storing configuration in the environment separate from code is based on The Twelve-Factor App methodology.
- [eventsource](https://www.npmjs.com/package/eventsource): WhatWG/W3C-compatible server-sent events/eventsource client. The module attempts to implement an absolute minimal amount of features/changes beyond the specification.


---

